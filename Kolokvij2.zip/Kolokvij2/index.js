let broj1 =prompt("Unesi neki broj: ")
alert("Unio si broj: " + broj1 + ", a dva puta veći broj je: " + broj1*2)